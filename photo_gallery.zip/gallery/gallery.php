







<?php

error_reporting(E_ALL); // Enable all error reporting
ini_set('display_errors', 1); // Show errors on screen
ini_set('display_startup_errors', 1); // Show startup errors





session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'config.php';

// Handle image upload only when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['image'])) {
    $imageTitle = trim($_POST['title']);
    $image = $_FILES['image'];

    // Validate file
    if ($image['size'] > 5000000) {
        $error = "File too large. Max 5MB allowed.";
    } elseif (!in_array($image['type'], ['image/jpeg', 'image/png', 'image/gif'])) {
        $error = "Only JPG, PNG, and GIF formats are allowed.";
    } else {
        // Read image binary data
        $imageData = file_get_contents($image['tmp_name']);
        $mimeType = $image['type'];

        try {
            // Insert into database
            $stmt = $pdo->prepare("INSERT INTO images (user_id, title, image_data, mime_type) VALUES (?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $imageTitle, $imageData, $mimeType]);
            
            // After successful upload, redirect to the same page to prevent re-upload
            header("Location: gallery.php");
            exit();
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// Fetch images from the database
$stmt = $pdo->prepare("SELECT title, image_data, mime_type FROM images WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Gallery</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Welcome, <?= htmlspecialchars($_SESSION['username']); ?></h1>
    <a href="logout.php">Logout</a>

    <h2>Upload a New Image</h2>
    <form action="gallery.php" method="POST" enctype="multipart/form-data">
        <label for="title">Image Title:</label>
        <input type="text" name="title" id="title" required>
        <label for="image">Choose an Image:</label>
        <input type="file" name="image" id="image" required>
        <button type="submit">Upload Image</button>
        <?php if (isset($error)): ?><p class="error"><?= htmlspecialchars($error); ?></p><?php endif; ?>
        <?php if (isset($success)): ?><p class="success"><?= htmlspecialchars($success); ?></p><?php endif; ?>
    </form>

    <h2>Your Gallery</h2>
    <div class="gallery">
    <?php if ($images): ?>
    <?php foreach ($images as $image): ?>
        <div class="gallery-item">
            <p><?= htmlspecialchars($image['title'], ENT_QUOTES, 'UTF-8'); ?></p>
            <img src="data:<?= htmlspecialchars($image['mime_type'], ENT_QUOTES, 'UTF-8'); ?>;base64,<?= base64_encode($image['image_data']); ?>" 
                 alt="<?= htmlspecialchars($image['title'], ENT_QUOTES, 'UTF-8'); ?>">
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>No images uploaded yet.</p>
<?php endif; ?>

    </div>
</div>

    </div>
</body>
</html>
